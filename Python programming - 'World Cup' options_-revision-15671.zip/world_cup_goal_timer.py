import time

go_again="y"

start_time=time.time()

print("Game has started!")

while go_again=="y":

    key=str(input("H for home goal... A for away goal"))

    if key=="H" or key=="h":
        home_goal_time=time.time()
        time_diff=home_goal_time-start_time
        print("Home goal scored at ",round(time_diff,2),"seconds")

    if key=="A" or key=="a":
        away_goal_time=time.time()
        time_diff=away_goal_time-start_time
        print("Away goal scored at ",round(time_diff,2),"seconds")
    
    print()
    go_again=str(input("Continue (y/n)"))
    
print("Done!")

