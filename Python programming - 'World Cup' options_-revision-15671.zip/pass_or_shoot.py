import random

print("World Cup Semis...")

def choose_pass_or_shoot():
    global pass_or_shoot
    pass_or_shoot=str(input("(p)ass or (s)hoot...?"))


def pass_the_ball():
    if pass_or_shoot=="p":
        success=random.randint(1,2)
        if success==1:
            print("Successful pass. Well done!")
            choose_pass_or_shoot()
            if pass_or_shoot=="p":
                pass_the_ball()
            elif pass_or_shoot=="s":
                shoot()
        else:
            print("Bad luck. Opponent takes the ball")

def shoot():
    pass_or_shoot=="s"
    success=random.randint(1,2)
    if success==1:
        print("You shoot... you SCORE!")
    else:
        print("Ball goes over the bar... :(")


# main program begins here
choose_pass_or_shoot()
if pass_or_shoot=="p":
    pass_the_ball()
elif pass_or_shoot=="s":
    shoot()
