import random

print("World Cup Penalty Shootout")

ball_kick=random.choice(["Goal!","Over the bar","Wide","Keeper save!"])

if ball_kick=="Goal!":
    print(ball_kick)
elif ball_kick=="Over the bar":
    print(ball_kick)
elif ball_kick=="Wide":
    print(ball_kick)
elif ball_kick=="Keeper save!":
    print(ball_kick)
    


